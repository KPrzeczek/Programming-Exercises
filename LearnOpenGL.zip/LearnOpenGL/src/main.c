#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stdio.h>
#include <math.h>
#include <cglm/cglm.h>

#include "defines.h"
#include "shader/shader.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

internal void FramebufferSizeCallback(GLFWwindow *window, int width, int height);
internal void SetCursorPosCallback(GLFWwindow *window, f64 x_pos, f64 y_pos);
internal void ProcessInput(GLFWwindow *window);

global vec3 camera_pos = { 0.0f, 0.0f, 3.0f };
global vec3 camera_front = { 0.0f, 0.0f, -1.0f };
global vec3 camera_up = { 0.0f, 1.0f, 0.0f };

global f32 delta_t;

global f32 last_mouse_x = WINDOW_WIDTH / 2;
global f32 last_mouse_y = WINDOW_HEIGHT / 2;
global f32 camera_roll;
global f32 camera_yaw;
global f32 camera_pitch;

int
main(void)
{
    // NOTE(kmp): Load GLFW3
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    
    GLFWwindow *window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT,
                                          "Learn OpenGL",
                                          NULL, NULL);
    if (!window)
    {
        printf("Failed to create GLFW window!\n");
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    
    // NOTE(kmp): Load GLaD(OS)
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        printf("Failed to initialize GLaD(OS)\n");
        return -1;
    }    
    
    glViewport(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT);
    
    // NOTE(kmp): Keyboard
    glfwSetFramebufferSizeCallback(window, FramebufferSizeCallback);
    
    // NOTE(kmp): Mouse
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);  
    glfwSetCursorPosCallback(window, SetCursorPosCallback); 
    
    // NOTE(kmp): Make images load in upside down since OpenGL has issues and loads the images in like a big dumdum
    stbi_set_flip_vertically_on_load(1);
    
    // NOTE(kmp): Enable Depth
    glEnable(GL_DEPTH_TEST);
    
    // NOTE(kmp): Forest Texture
    u32 forest_texture;
    glGenTextures(1, &forest_texture);
    glBindTexture(GL_TEXTURE_2D, forest_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    i32 frs_tex_w, frs_tex_h, frs_nr_channels;
    unsigned char *forest_data = stbi_load("D:\\_Programming_Projects\\C\\LearnOpenGL\\res\\txrs\\forest.png",
                                           &frs_tex_w, &frs_tex_h, &frs_nr_channels, 0);
    if (forest_data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, frs_tex_w, frs_tex_h, 0, GL_RGB, GL_UNSIGNED_BYTE, forest_data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    
    stbi_image_free(forest_data);
    
    // NOTE(kmp): Speaker Texture
    u32 speaker_texture;
    glGenTextures(1, &speaker_texture);
    glBindTexture(GL_TEXTURE_2D, speaker_texture);
    i32 spk_tex_w, spk_tex_h, spk_nr_channels;
    unsigned char *speaker_data = stbi_load("D:\\_Programming_Projects\\C\\LearnOpenGL\\res\\txrs\\speaker.png",
                                            &spk_tex_w, &spk_tex_h, &spk_nr_channels, 0);
    if (speaker_data)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, spk_tex_w, spk_tex_h, 0, GL_RGBA, GL_UNSIGNED_BYTE, speaker_data);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    
    stbi_image_free(speaker_data);
    
    // NOTE(kmp): Projection Matrix
    mat4 projection_matrix;
    glm_perspective(45.0f * DEG2RAD, WINDOW_WIDTH / WINDOW_HEIGHT, 0.1f, 100.0f, projection_matrix);
    
    // NOTE(kmp): Shader Setup
    Shader out_shader;
    ShaderInit(&out_shader,
               "D:\\_Programming_Projects\\C\\LearnOpenGL\\res\\shdrs\\vertex.glsl",
               "D:\\_Programming_Projects\\C\\LearnOpenGL\\res\\shdrs\\fragment.glsl");
    ShaderUse(&out_shader);
    SetShaderInt(&out_shader, "texture0", 0);
    SetShaderInt(&out_shader, "texture1", 1);
    SetShaderMat4f(&out_shader, "projection", projection_matrix);
    
    // NOTE(kmp): Vertices
    GLfloat vertices[] = {
        //-------------------+-------------+
        //    POSITION       |   TEXCOORD  |
        //-------------------+-------------+
        -0.5f, -0.5f, -0.5f,    0.0f,  0.0f,
        +0.5f, -0.5f, -0.5f,   +1.0f,  0.0f,
        +0.5f, +0.5f, -0.5f,   +1.0f, +1.0f,
        +0.5f, +0.5f, -0.5f,   +1.0f, +1.0f,
        -0.5f, +0.5f, -0.5f,    0.0f, +1.0f,
        -0.5f, -0.5f, -0.5f,    0.0f,  0.0f,
        
        -0.5f, -0.5f, +0.5f,    0.0f,  0.0f,
        +0.5f, -0.5f, +0.5f,   +1.0f,  0.0f,
        +0.5f, +0.5f, +0.5f,   +1.0f, +1.0f,
        +0.5f, +0.5f, +0.5f,   +1.0f, +1.0f,
        -0.5f, +0.5f, +0.5f,    0.0f, +1.0f,
        -0.5f, -0.5f, +0.5f,    0.0f,  0.0f,
        
        -0.5f, +0.5f, +0.5f,   +1.0f,  0.0f,
        -0.5f, +0.5f, -0.5f,   +1.0f, +1.0f,
        -0.5f, -0.5f, -0.5f,    0.0f, +1.0f,
        -0.5f, -0.5f, -0.5f,    0.0f, +1.0f,
        -0.5f, -0.5f, +0.5f,    0.0f,  0.0f,
        -0.5f, +0.5f, +0.5f,   +1.0f,  0.0f,
        
        +0.5f, +0.5f, +0.5f,   +1.0f,  0.0f,
        +0.5f, +0.5f, -0.5f,   +1.0f, +1.0f,
        +0.5f, -0.5f, -0.5f,    0.0f, +1.0f,
        +0.5f, -0.5f, -0.5f,    0.0f, +1.0f,
        +0.5f, -0.5f, +0.5f,    0.0f,  0.0f,
        +0.5f, +0.5f, +0.5f,   +1.0f,  0.0f,
        
        -0.5f, -0.5f, -0.5f,    0.0f, +1.0f,
        +0.5f, -0.5f, -0.5f,   +1.0f, +1.0f,
        +0.5f, -0.5f, +0.5f,   +1.0f,  0.0f,
        +0.5f, -0.5f, +0.5f,   +1.0f,  0.0f,
        -0.5f, -0.5f, +0.5f,    0.0f,  0.0f,
        -0.5f, -0.5f, -0.5f,    0.0f, +1.0f,
        
        -0.5f, +0.5f, -0.5f,    0.0f, +1.0f,
        +0.5f, +0.5f, -0.5f,   +1.0f, +1.0f,
        +0.5f, +0.5f, +0.5f,   +1.0f,  0.0f,
        +0.5f, +0.5f, +0.5f,   +1.0f,  0.0f,
        -0.5f, +0.5f, +0.5f,    0.0f,  0.0f,
        -0.5f, +0.5f, -0.5f,    0.0f, +1.0f
    };
    
    /* 
        GLfloat vertices[] = {
            //    POSITION         TEXCOORD
            +0.5f, +0.5f, 0.0f,   +1.0f, +1.0f,
            +0.5f, -0.5f, 0.0f,   +1.0f,  0.0f,
            -0.5f, -0.5f, 0.0f,    0.0f,  0.0f,
            -0.5f, +0.5f, 0.0f,    0.0f, +1.0f
        };
     */
    
    vec3 cube_positions[] = {
        {  0.0f,  0.0f,  0.0f }, 
        { +2.0f, +5.0f, -15.0f }, 
        { -1.5f, -2.2f, -2.5f },  
        { -3.8f, -2.0f, -12.3f },  
        { +2.4f, -0.4f, -3.5f },  
        { -1.7f, +3.0f, -7.5f },  
        { +1.3f, -2.0f, -2.5f },  
        { +1.5f, +2.0f, -2.5f }, 
        { +1.5f, +0.2f, -1.5f }, 
        { -1.3f, +1.0f, -1.5f }
    };
    
    // NOTE(kmp): Indices
    u32 indices[] = {
        0, 1, 3,
        1, 2, 3
    };
    
    // NOTE(kmp): VBO
    u32 VBO;
    glGenBuffers(1, &VBO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    
    // NOTE(kmp): VAO
    u32 VAO;
    glGenVertexArrays(1, &VAO);
    glBindVertexArray(VAO);
    
    // NOTE(kmp): EBO
    u32 EBO;
    glGenBuffers(1, &EBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    
    // NOTE(kmp): VertexAttribPointer
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(f32), (void*)(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(f32), (void*)(3 * sizeof(f32)));
    glEnableVertexAttribArray(1);
    
    // NOTE(kmp): Polygon Mode
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    
    // NOTE(kmp): Main Loop
    float last_frame = 0.0f;
    while (!glfwWindowShouldClose(window))
    {
        // NOTE(kmp): Delta Time
        float current_frame = glfwGetTime();
        delta_t = current_frame - last_frame;
        last_frame = current_frame;  
        
        // NOTE(kmp): Handle Events
        ProcessInput(window);
        
        // NOTE(kmp): Clear Screen
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
        // NOTE(kmp): Enable Shader
        ShaderUse(&out_shader);
        
        // NOTE(kmp): View Matrix
        mat4 view_matrix = GLM_MAT4_IDENTITY_INIT;
        vec3 cam_pos_add_front;
        glm_vec3_add(camera_pos, camera_front, cam_pos_add_front);
        glm_lookat(camera_pos,
                   cam_pos_add_front,
                   camera_up,
                   view_matrix);
        SetShaderMat4f(&out_shader, "view", view_matrix);
        
        // NOTE(kmp): Set time of the wave shader
        SetShaderFloat(&out_shader, "tx", glfwGetTime());
        SetShaderFloat(&out_shader, "ty", glfwGetTime());
        
        // NOTE(kmp): Bind Textures
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, forest_texture);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, speaker_texture);
        
        // NOTE(kmp): Draw to window
        glBindVertexArray(VAO);
        for (u32 ii = 0; ii < 10; ii++)
        {
            mat4 model = GLM_MAT4_IDENTITY_INIT;
            glm_translate(model, cube_positions[ii]);
            f32 angle = 20.0f * ii;
            vec3 rot = { 1.0f, 0.3f, 0.5f };
            glm_rotate(model, angle * DEG2RAD, rot);
            SetShaderMat4f(&out_shader, "model", model);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }
        //glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        //glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
        
        // NOTE(kmp): Update Window
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    
    // Clean Up Resources
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);
    
    // Terminate GLFW
    glfwTerminate();
    
    // End!
    return 0;
}

internal void
FramebufferSizeCallback(GLFWwindow *window, i32 width, i32 height)
{
    // NOTE(kmp): Resize Window
    glViewport(0, 0, width, height);
}

internal void
ProcessInput(GLFWwindow *window)
{
    // NOTE(kmp): Exit Window
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {
        glfwSetWindowShouldClose(window, 1);
    }
    
    // NOTE(kmp): Wireframe Mode
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    }
    
    // NOTE(kmp): Normal Mode
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    }
    
    // NOTE(kmp): Camera Controls
    f32 spd = 2.0f * delta_t;
    vec3 camera_speed = { spd, spd * 2, spd * 2 };
    
    // Forward
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
    {
        vec3 mult;
        glm_vec3_mul(camera_speed, camera_front, mult);
        glm_vec3_add(camera_pos, mult, camera_pos);
    }
    
    // Back
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
    {
        vec3 mult;
        glm_vec3_mul(camera_speed, camera_front, mult);
        glm_vec3_sub(camera_pos, mult, camera_pos);
    }
    
    // Up
    if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
    {
        vec4 mult;
        glm_vec3_mul(camera_speed, camera_up, mult);
        glm_vec3_add(camera_pos, mult, camera_pos);
    }
    
    // Down
    if (glfwGetKey(window, GLFW_KEY_LEFT_SHIFT) == GLFW_PRESS)
    {
        vec4 mult;
        glm_vec3_mul(camera_speed, camera_up, mult);
        glm_vec3_sub(camera_pos, mult, camera_pos);
    }
    
    // Left
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
    {
        vec3 temp;
        glm_vec3_cross(camera_front, camera_up, temp);
        glm_vec3_norm(temp);
        vec3 mult;
        glm_vec3_mul(temp, camera_speed, mult);
        glm_vec3_sub(camera_pos, mult, camera_pos);
    }
    
    // Right
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
    {
        vec3 temp;
        glm_vec3_cross(camera_front, camera_up, temp);
        glm_vec3_norm(temp);
        vec3 mult;
        glm_vec3_mul(temp, camera_speed, mult);
        glm_vec3_add(camera_pos, mult, camera_pos);
    }
}

internal void
SetCursorPosCallback(GLFWwindow *window, f64 xpos, f64 ypos)
{
    float xoffset = xpos - last_mouse_x;
    float yoffset = last_mouse_y - ypos;
    last_mouse_x = xpos;
    last_mouse_y = ypos;
    
    float sensitivity = 0.1f;
    xoffset *= sensitivity;
    yoffset *= sensitivity;
    
    camera_yaw += xoffset;
    camera_pitch += yoffset;
    
    if(camera_pitch > 89.0f)
        camera_pitch = 89.0f;
    if(camera_pitch < -89.0f)
        camera_pitch = -89.0f;
    
    vec3 direction;
    direction[0] = cos(camera_yaw * DEG2RAD) * cos(camera_pitch * DEG2RAD);
    direction[1] = sin(camera_pitch * DEG2RAD);
    direction[2] = sin(camera_yaw * DEG2RAD) * cos(camera_pitch * DEG2RAD);
    glm_vec3_norm(direction);
    glm_vec3_copy(direction, camera_front);
}
