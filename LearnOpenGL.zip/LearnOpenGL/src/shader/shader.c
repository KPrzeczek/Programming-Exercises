#include "shader.h"

#include <glad/glad.h>
#include <stdio.h>

#include <stdlib.h>

void
ShaderInit(Shader *shader, const char *vertex_path, const char *fragment_path)
{
    FILE *vert_f = fopen(vertex_path, "rb");
    char *vert_buf = 0;
    long vert_len;
    
    FILE *frag_f = fopen(fragment_path, "rb");
    char *frag_buf = 0;
    long frag_len;
    
    if (vert_f)
    {
        fseek(vert_f, 0, SEEK_END);
        vert_len = ftell(vert_f);
        
        fseek(vert_f, 0, SEEK_SET);
        vert_buf = malloc(vert_len + 1);
        
        if (vert_buf)
        {
            fread(vert_buf, 1, vert_len, vert_f);
            *(vert_buf+vert_len) = 0;
        }
        
        fclose(vert_f);
    }
    else
    {
        printf("ERROR::SHADER::VERTEX::FILE_NULL\n");
    }
    
    if (frag_f)
    {
        fseek(frag_f, 0, SEEK_END);
        frag_len = ftell(frag_f);
        
        fseek(frag_f, 0, SEEK_SET);
        frag_buf = malloc(frag_len + 1);
        
        if (frag_buf)
        {
            fread(frag_buf, 1, frag_len, frag_f);
            *(frag_buf+frag_len) = 0;
        }
        
        fclose(frag_f);
    }
    else
    {
        printf("ERROR::SHADER::FRAGMENT::FILE_NULL\n");
    }
    
    b32 success;
    char infolog[512];
    
    u32 vertex = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertex, 1, &vert_buf, NULL);
    glCompileShader(vertex);
    glGetShaderiv(vertex, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertex, 512, NULL, infolog);
        printf("ERROR::SHADER::VERTEX::COMPILATION_FAILED => %s\n", infolog);
    }
    
    u32 fragment = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragment, 1, &frag_buf, NULL);
    glCompileShader(fragment);
    glGetShaderiv(fragment, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragment, 512, NULL, infolog);
        printf("ERROR::SHADER::FRAGMENT::COMPILATION_FAILED => %s\n", infolog);
    }
    
    shader->id = glCreateProgram();
    glAttachShader(shader->id, vertex);
    glAttachShader(shader->id, fragment);
    glLinkProgram(shader->id);
    glGetProgramiv(shader->id, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(shader->id, 512, NULL, infolog);
        printf("ERROR::SHADER::PROGRAM::LINKING_FAILED => %s\n", infolog);
    }
    
    glDeleteShader(vertex);
    glDeleteShader(fragment);
}

void
ShaderUse(Shader *shader)
{
    glUseProgram(shader->id);
}

void
SetShaderBool(Shader *shader, const char *name, b32 value)
{
    glUniform1i(glGetUniformLocation(shader->id, name), value);
}

void
SetShaderInt(Shader *shader, const char *name, i32 value)
{
    glUniform1i(glGetUniformLocation(shader->id, name), value);
}

void
SetShaderFloat(Shader *shader, const char *name, f32 value)
{
    glUniform1f(glGetUniformLocation(shader->id, name), value);
}

void
SetShaderMat4f(Shader *shader, const char *name, mat4 value)
{
    glUniformMatrix4fv(glGetUniformLocation(shader->id, name),
                       1, GL_FALSE,
                       value[0]);
}
