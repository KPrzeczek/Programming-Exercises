#ifndef SHADER_H
#define SHADER_H

#include "../defines.h"

#include <cglm/cglm.h>

typedef struct Shader
{
    u32 id;
} Shader;

void ShaderInit(Shader *shader, const char *vertex_path, const char *fragment_path);
void ShaderUse(Shader *shader);

void SetShaderBool(Shader *shader, const char *name, b32 value);
void SetShaderInt(Shader *shader, const char *name, i32 value);
void SetShaderFloat(Shader *shader, const char *name, f32 value);
void SetShaderMat4f(Shader *shader, const char *name, mat4 value);

#endif //SHADER_H
