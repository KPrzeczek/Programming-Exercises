#ifndef DEFINES_H
#define DEFINES_H

#include <stdint.h>

// NOTE(kmp): Numbers
typedef int8_t i8;
typedef int16_t i16;
typedef int32_t i32;
typedef int64_t i64;

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

typedef float f32;
typedef double f64;

typedef uint64_t b64;
typedef uint32_t b32;
typedef uint16_t b16;
typedef uint8_t b8;

// NOTE(kmp): Math
#define PI 3.14159265
#define DEG2RAD (PI / 180)
#define RAD2DEG (180 / PI)

// NOTE(kmp): Keywords
#define internal static
#define global static

// NOTE(kmp): Screen
#define WINDOW_WIDTH 1280
#define WINDOW_HEIGHT 720

#endif //DEFINES_H
