#!/bin/bash

code="$PWD"
opts=-g
cd build > /dev/null
g++ $opts $code/main.c -o LearnOpenGL
cd $code > /dev/null
