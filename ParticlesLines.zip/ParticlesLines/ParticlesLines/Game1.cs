﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace ParticlesLines
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        private MouseState previousMouseState;
        private Texture2D floatingCircleTex;
        
        private List<FloatingCircle> circles;
        private LineManager lineManager;

        public static Random Random;

        public static int Width = 1280;
        public static int Height = 720;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            Random = new Random();

            graphics.PreferredBackBufferWidth = Width;
            graphics.PreferredBackBufferHeight = Height;
            graphics.ApplyChanges();

            IsMouseVisible = true;
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            circles = new List<FloatingCircle>();
            lineManager = new LineManager(circles);

            floatingCircleTex = Content.Load<Texture2D>("circle");

            for(int ii = 0; ii < 125; ii++)
                circles.Add(new FloatingCircle(floatingCircleTex));
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            float dt = (float)gameTime.ElapsedGameTime.TotalSeconds;

			if(Mouse.GetState().LeftButton == ButtonState.Pressed && previousMouseState.LeftButton != ButtonState.Pressed)
			{
                for(int ii = 0; ii < 5; ii++)
				{
					var circle = new FloatingCircle(floatingCircleTex);
					circle.Position = new Vector2(Mouse.GetState().X, Mouse.GetState().Y);
					circles.Add(circle);
				}
			}

			foreach(var circle in circles)
                circle.Update(dt);

            lineManager.Update(dt);
            previousMouseState = Mouse.GetState();
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(new Color(73, 76, 82));
            spriteBatch.Begin();

			foreach(var circle in circles)
				circle.Draw((float)gameTime.ElapsedGameTime.TotalSeconds, spriteBatch);

            lineManager.Draw((float)gameTime.ElapsedGameTime.TotalSeconds, spriteBatch);
            spriteBatch.End();
			base.Draw(gameTime);
        }
    }
}
