﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;

namespace ParticlesLines
{
	public class FloatingCircle
	{
		private readonly float MOVE_SPEED = 20f;

		private Texture2D texture;

		private Vector2 position;
		private Vector2 origin;
		private float scale;
		private Vector2 direction;
		private Vector2 velocity;

		public Vector2 Position
		{
			get => position;
			set => position = value;
		}

		public FloatingCircle(Texture2D tex)
		{
			texture = tex;
			origin = new Vector2(texture.Width / 2, texture.Height / 2);
			scale = 1 / 48f;

			position = new Vector2(Game1.Random.Next(0, Game1.Width), Game1.Random.Next(0, Game1.Height));

			float dir = Game1.Random.Next(0, 359);

			direction.X = -(float)Math.Sin(dir * 2 * Math.PI / 360);
			direction.Y = (float)Math.Cos(dir * 2 * Math.PI / 360);
			direction.Normalize();
		}

		public void Update(float deltaTime)
		{
			velocity = direction * MOVE_SPEED * deltaTime;
			position += velocity;

			if(position.X <= -texture.Width * scale)
				position.X = Game1.Width + texture.Width * scale;
			else if(position.X >= Game1.Width + texture.Width * scale)
				position.X = -texture.Width * scale;
			if(position.Y <= -texture.Height * scale)
				position.Y = Game1.Height + texture.Height * scale;
			else if(position.Y >= Game1.Height + texture.Height * scale)
				position.Y = -texture.Height * scale;
		}

		public void Draw(float deltaTime, SpriteBatch spriteBatch)
		{
			spriteBatch.Draw(texture, position, null, Color.White * 0.7f, 0f, origin, scale, SpriteEffects.None, 0.5f);
		}
	}
}
